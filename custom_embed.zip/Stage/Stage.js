/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 240,
        y: 180
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];

    this.vars.myVariable = 0;
    this.vars.embedLink =
      '<iframe src="google.com" allowtransparency="true" width="100%" height="100%" frameborder="0" scrolling="yes" allowfullscreen></iframe>';
  }

  *whenGreenFlagClicked() {
    yield* this.askAndWait("Insert link you want to embed");
    if (this.answer == this.answer) {
      this.vars.embedLink =
        "" +
        ("" + '<iframe src="' + this.answer) +
        '" allowtransparency="true" width="100%" height="100%" frameborder="0" scrolling="yes" allowfullscreen></iframe>';
    }
  }
}
